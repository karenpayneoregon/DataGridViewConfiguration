﻿Public Class Form1

    Private _fileName As String = ""
    Private _bsCustomers As New BindingSource

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        _fileName = IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, DataGridView1.Name & ".xml")

        Dim ds As New DataSet
        ds.ReadXml(IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Customers.xml"))
        _bsCustomers.DataSource = ds.Tables("Customer")
        DataGridView1.DataSource = _bsCustomers

        If IO.File.Exists(_fileName) Then
            For Each col In DataGridView1.Columns.Cast(Of DataGridViewColumn)().ToList
                col.Visible = False
            Next

            ds = New DataSet()
            ds.ReadXml(_fileName)
            Dim temp = ds.Tables(DataGridView1.Name)
            For i As Integer = 0 To temp.Rows.Count - 1
                DataGridView1.Columns(CStr(temp.Rows(i).Item("ColumnName"))).Visible = CBool(temp.Rows(i).Item("Action"))
                DataGridView1.Columns(CStr(temp.Rows(i).Item("ColumnName"))).DisplayIndex = CInt(temp.Rows(i).Item("DisplayIndex"))
            Next

        End If
    End Sub
    Private Sub cmdShowHide_Click(sender As Object, e As EventArgs) Handles cmdShowHide.Click
        Dim f As New frmDisplayColumns(DataGridView1)
        Try
            f.ShowDialog()
        Finally
            f.Dispose()
        End Try
    End Sub
    Private Sub cmdExpandColumns_Click(sender As Object, e As EventArgs) Handles cmdExpandColumns.Click
        DataGridView1.ExpandColumns()
    End Sub
End Class
