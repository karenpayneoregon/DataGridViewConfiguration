﻿Imports System.Xml.Linq

Public Class frmDisplayColumns

    Private bsColumns As New BindingSource
    Private _table As New DataTable
    Private _gridView As DataGridView
    Private fileName As String = ""
    Private _ds As New DataSet With {.DataSetName = "DataGridViewConfigurations"}
    Private _filledFromXml As Boolean = False

    Public Sub New(ByRef dgvPrimary As DataGridView)
        InitializeComponent()

        _gridView = dgvPrimary

        _table.TableName = dgvPrimary.Name
        _table.Columns.AddRange(New DataColumn() {New DataColumn("Action", GetType(Boolean)), New DataColumn("ColumnName", GetType(String)), New DataColumn("DisplayIndex", GetType(Integer))})


        fileName = IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, dgvPrimary.Name & ".xml")

        If IO.File.Exists(fileName) Then
            _filledFromXml = True
            _ds.ReadXml(fileName)
            Dim tempTable = _ds.Tables(dgvPrimary.Name)
            For i As Integer = 0 To tempTable.Rows.Count - 1
                _table.Rows.Add(CBool(tempTable.Rows(i).Item(0)), tempTable.Rows(i).Item(1), CInt(tempTable.Rows(i).Item(2)))
            Next
        End If

    End Sub
    Private Sub DisplayColumns_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        If Not _filledFromXml Then
            For Each Col As DataGridViewColumn In _gridView.Columns
                _table.Rows.Add(New Object() {Col.Visible, Col.Name})
            Next
        End If

        bsColumns.DataSource = _table
        DataGridView1.DataSource = bsColumns
        DataGridView1.Columns("Action").HeaderText = "Visible"
        DataGridView1.Columns("ColumnName").HeaderText = "Column name"
        DataGridView1.Columns("ColumnName").AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
        DataGridView1.Columns("DisplayIndex").Visible = False

    End Sub
    Private Sub cmdApply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdApply.Click
        For rowIndex As Integer = 0 To _table.Rows.Count - 1
            Dim row = _table.Rows(rowIndex)
            row.SetField(Of Integer)("DisplayIndex", rowIndex)
            _gridView.Columns(row.Field(Of String)("ColumnName")).Visible = row.Field(Of Boolean)("Action")
            If _gridView.Columns(row.Field(Of String)("ColumnName")).Visible Then
                _gridView.Columns(row.Field(Of String)("ColumnName")).DisplayIndex = row.Field(Of Integer)("DisplayIndex")
            End If
        Next

        Dim ds As New DataSet With {.DataSetName = "DataGridViewConfigurations"}
        ds.Tables.Add(_table)
        ds.WriteXml(fileName)
    End Sub
    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Close()
    End Sub
    Private Sub cmdUp_Click(sender As Object, e As EventArgs) Handles cmdUp.Click
        DataGridView1.MoveRowUp(bsColumns)
    End Sub
    Private Sub cmdDown_Click(sender As Object, e As EventArgs) Handles cmdDown.Click
        DataGridView1.MoveRowDown(bsColumns)
    End Sub
End Class